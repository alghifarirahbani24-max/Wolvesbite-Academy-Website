// === FORM BOOKING (CREATE) ===
const formBooking = document.getElementById("formBooking");
if (formBooking) {
  formBooking.addEventListener("submit", function (e) {
    e.preventDefault();

    const nama = document.getElementById("nama").value;
    const email = document.getElementById("email").value;
    const telepon = document.getElementById("telepon").value;
    const tanggal = document.getElementById("tanggal").value;
    const waktu = document.getElementById("waktu").value;
    const catatan = document.getElementById("catatan").value;

    // Ambil data dari localStorage atau buat array kosong
    let bookingData = [];
    try {
      const stored = localStorage.getItem("bookingLapangan");
      if (stored) {
        bookingData = JSON.parse(stored);
      }
    } catch (error) {
      console.error("Error reading localStorage:", error);
      bookingData = [];
    }

    // Buat booking baru
    const newBooking = {
      id: Date.now(),
      nama: nama,
      email: email,
      telepon: telepon,
      tanggal: tanggal,
      waktu: waktu,
      catatan: catatan
    };

    // Tambahkan ke array
    bookingData.push(newBooking);

    // Simpan ke localStorage
    try {
      localStorage.setItem("bookingLapangan", JSON.stringify(bookingData));
      console.log("Data tersimpan:", bookingData); // Debug
      
      alert("✅ Booking berhasil dikirim! Kami akan menghubungi Anda untuk konfirmasi.\n\nSilahkan cek di menu KELOLA untuk melihat booking Anda.");
      
      // Reset form
      document.getElementById("formBooking").reset();
    } catch (error) {
      console.error("Error saving to localStorage:", error);
      alert("❌ Terjadi kesalahan saat menyimpan data. Silakan coba lagi.");
    }
  });
}

// === GALERI FOTO POPUP ===
let fotoIndex = 0;
const popup = document.getElementById("popupGallery");
const semuaFoto = document.querySelectorAll(".gallery-img");

function tampilkanFoto() {
  if (popup) {
    popup.classList.add("active");
    fotoIndex = 0;
    tampilkanFotoAktif();
  }
}

function tutupGaleri() {
  if (popup) {
    popup.classList.remove("active");
  }
}

function tampilkanFotoAktif() {
  semuaFoto.forEach((img, i) => {
    img.classList.toggle("active", i === fotoIndex);
  });
}

function nextFoto() {
  fotoIndex = (fotoIndex + 1) % semuaFoto.length;
  tampilkanFotoAktif();
}

function prevFoto() {
  fotoIndex = (fotoIndex - 1 + semuaFoto.length) % semuaFoto.length;
  tampilkanFotoAktif();
}

// Tutup galeri kalau user klik di luar gambar
if (popup) {
  popup.addEventListener("click", (e) => {
    if (e.target === popup) tutupGaleri();
  });
}

// === READ: TAMPILKAN DAFTAR BOOKING ===
function tampilkanDaftarBooking() {
  const bookingList = document.getElementById("bookingList");
  if (!bookingList) return; // Hanya jalan di halaman manage
  
  console.log("Memuat daftar booking..."); // Debug
  
  let bookingData = [];
  try {
    const stored = localStorage.getItem("bookingLapangan");
    console.log("Data dari localStorage:", stored); // Debug
    
    if (stored) {
      bookingData = JSON.parse(stored);
      console.log("Parsed data:", bookingData); // Debug
    }
  } catch (error) {
    console.error("Error reading localStorage:", error);
    bookingData = [];
  }
  
  if (bookingData.length === 0) {
    bookingList.innerHTML = `
      <div class="no-data">
        <p>📭</p>
        <p>Belum ada booking tersimpan.</p>
        <p style="font-size: 0.9rem; margin-top: 10px;">Silakan buat booking baru di halaman Booking.</p>
      </div>
    `;
    return;
  }
  
  // Urutkan dari terbaru
  bookingData.sort((a, b) => b.id - a.id);
  
  bookingList.innerHTML = bookingData.map(booking => {
    const tanggalObj = new Date(booking.tanggal);
    const tanggalFormat = tanggalObj.toLocaleDateString('id-ID', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
    
    return `
      <div class="booking-card" data-id="${booking.id}">
        <div class="booking-header">
          <h3>${booking.nama}</h3>
          <span class="booking-date">${tanggalFormat}</span>
        </div>
        <div class="booking-info">
          <p><strong>📧 Email:</strong> ${booking.email}</p>
          <p><strong>📞 Telepon:</strong> ${booking.telepon}</p>
          <p><strong>⏰ Waktu:</strong> ${booking.waktu}</p>
          <p><strong>📝 Catatan:</strong> ${booking.catatan || '-'}</p>
        </div>
        <div class="booking-actions">
          <button class="btn-edit" onclick="editBooking(${booking.id})">✏️ Edit</button>
          <button class="btn-delete" onclick="hapusBooking(${booking.id})">🗑️ Hapus</button>
        </div>
      </div>
    `;
  }).join('');
  
  console.log("Daftar booking ditampilkan:", bookingData.length, "items"); // Debug
}

// === UPDATE: EDIT BOOKING ===
function editBooking(id) {
  console.log("Edit booking ID:", id); // Debug
  
  let bookingData = [];
  try {
    const stored = localStorage.getItem("bookingLapangan");
    if (stored) {
      bookingData = JSON.parse(stored);
    }
  } catch (error) {
    console.error("Error reading localStorage:", error);
    alert("❌ Terjadi kesalahan saat membaca data.");
    return;
  }
  
  const booking = bookingData.find(b => b.id === id);
  
  if (!booking) {
    alert("❌ Booking tidak ditemukan!");
    return;
  }
  
  // Isi form dengan data booking
  document.getElementById("editId").value = booking.id;
  document.getElementById("editNama").value = booking.nama;
  document.getElementById("editEmail").value = booking.email;
  document.getElementById("editTelepon").value = booking.telepon;
  document.getElementById("editTanggal").value = booking.tanggal;
  document.getElementById("editWaktu").value = booking.waktu;
  document.getElementById("editCatatan").value = booking.catatan || '';
  
  // Tampilkan modal edit
  const modal = document.getElementById("editModal");
  if (modal) {
    modal.style.display = "flex";
  }
}

function tutupEditModal() {
  const modal = document.getElementById("editModal");
  if (modal) {
    modal.style.display = "none";
  }
}

// Submit form edit
const formEdit = document.getElementById("formEdit");
if (formEdit) {
  formEdit.addEventListener("submit", function(e) {
    e.preventDefault();
    
    const id = parseInt(document.getElementById("editId").value);
    
    let bookingData = [];
    try {
      const stored = localStorage.getItem("bookingLapangan");
      if (stored) {
        bookingData = JSON.parse(stored);
      }
    } catch (error) {
      console.error("Error reading localStorage:", error);
      alert("❌ Terjadi kesalahan saat membaca data.");
      return;
    }
    
    const index = bookingData.findIndex(b => b.id === id);
    
    if (index === -1) {
      alert("❌ Booking tidak ditemukan!");
      return;
    }
    
    // Update data
    bookingData[index] = {
      id: id,
      nama: document.getElementById("editNama").value,
      email: document.getElementById("editEmail").value,
      telepon: document.getElementById("editTelepon").value,
      tanggal: document.getElementById("editTanggal").value,
      waktu: document.getElementById("editWaktu").value,
      catatan: document.getElementById("editCatatan").value
    };
    
    try {
      localStorage.setItem("bookingLapangan", JSON.stringify(bookingData));
      console.log("Data updated:", bookingData[index]); // Debug
      
      alert("✅ Booking berhasil diupdate!");
      tutupEditModal();
      tampilkanDaftarBooking();
    } catch (error) {
      console.error("Error saving to localStorage:", error);
      alert("❌ Terjadi kesalahan saat menyimpan data.");
    }
  });
}

// === DELETE: HAPUS BOOKING ===
function hapusBooking(id) {
  console.log("Hapus booking ID:", id); // Debug
  
  if (!confirm("⚠️ Apakah Anda yakin ingin menghapus booking ini?\n\nData yang dihapus tidak dapat dikembalikan.")) {
    return;
  }
  
  let bookingData = [];
  try {
    const stored = localStorage.getItem("bookingLapangan");
    if (stored) {
      bookingData = JSON.parse(stored);
    }
  } catch (error) {
    console.error("Error reading localStorage:", error);
    alert("❌ Terjadi kesalahan saat membaca data.");
    return;
  }
  
  const originalLength = bookingData.length;
  bookingData = bookingData.filter(b => b.id !== id);
  
  if (bookingData.length === originalLength) {
    alert("❌ Booking tidak ditemukan!");
    return;
  }
  
  try {
    localStorage.setItem("bookingLapangan", JSON.stringify(bookingData));
    console.log("Data deleted, remaining:", bookingData.length); // Debug
    
    alert("✅ Booking berhasil dihapus!");
    tampilkanDaftarBooking();
  } catch (error) {
    console.error("Error saving to localStorage:", error);
    alert("❌ Terjadi kesalahan saat menyimpan data.");
  }
}

// === AUTO LOAD SAAT HALAMAN MANAGE DIMUAT ===
window.addEventListener('DOMContentLoaded', function() {
  console.log("Page loaded"); // Debug
  
  // Cek apakah di halaman manage
  if (document.getElementById("bookingList")) {
    console.log("Halaman manage booking terdeteksi"); // Debug
    tampilkanDaftarBooking();
  }
  
  // Cek localStorage
  const stored = localStorage.getItem("bookingLapangan");
  console.log("localStorage check:", stored); // Debug
});

// === FUNGSI DEBUG (HAPUS SETELAH TESTING) ===
function debugLocalStorage() {
  const stored = localStorage.getItem("bookingLapangan");
  console.log("=== DEBUG localStorage ===");
  console.log("Raw data:", stored);
  if (stored) {
    try {
      const parsed = JSON.parse(stored);
      console.log("Parsed data:", parsed);
      console.log("Jumlah booking:", parsed.length);
    } catch (e) {
      console.error("Error parsing:", e);
    }
  } else {
    console.log("Tidak ada data di localStorage");
  }
  console.log("========================");
}

// Jalankan debug saat halaman dimuat (HAPUS SETELAH TESTING)
debugLocalStorage();