// ======== CREATE (Dari Academy.html) ========

// Simpan data pendaftaran ke localStorage
function simpanPendaftaran() {
  const nama = document
    .querySelector('input[placeholder="Masukkan nama lengkap"]')
    .value.trim();
  const usia = document
    .querySelector('input[placeholder="Masukkan usia"]')
    .value.trim();
  const email = document
    .querySelector('input[placeholder="Masukkan email aktif"]')
    .value.trim();
  const telepon = document
    .querySelector('input[placeholder="Masukkan nomor telepon"]')
    .value.trim();
  const program = document.querySelector("select").value;

  if (!nama || !usia || !email || !telepon || !program) {
    alert("Harap lengkapi semua data sebelum mengirim!");
    return;
  }

  const dataBaru = {
    id: Date.now(),
    nama,
    usia,
    email,
    telepon,
    program,
  };

  // ambil data lama
  let daftar = JSON.parse(localStorage.getItem("pendaftaran")) || [];
  daftar.push(dataBaru);
  localStorage.setItem("pendaftaran", JSON.stringify(daftar));

  alert("Data berhasil disimpan! Silakan lanjut ke halaman konfirmasi.");
  window.location.href = "sumbit academy.html";
}

// Jalankan saat tombol diklik
document.addEventListener("DOMContentLoaded", () => {
  const tombol = document.querySelector(".btn.primary");
  if (tombol) tombol.addEventListener("click", simpanPendaftaran);
});

// ======== READ, UPDATE, DELETE (Dari sumbit academy.html) ========

function tampilkanData() {
  const daftar = JSON.parse(localStorage.getItem("pendaftaran")) || [];
  const container = document.querySelector(".container");

  if (daftar.length === 0) {
    container.innerHTML += `<p style="text-align:center;color:#ccc;margin-top:10px;">Belum ada data pendaftaran.</p>`;
    return;
  }

  // tampilkan data terakhir yang dimasukkan
  const data = daftar[daftar.length - 1];

  document.getElementById("konfNama").value = data.nama;
  document.getElementById("konfUsia").value = data.usia;
  document.getElementById("konfEmail").value = data.email;
  document.getElementById("konfTelepon").value = data.telepon;
  document.querySelector("select").value = data.program;

  // tambahkan tombol Edit dan Hapus di bawah tombol yang ada
  const btnGroup = document.querySelector(".btn-group");
  if (btnGroup) {
    const editBtn = document.createElement("button");
    editBtn.textContent = "Edit Data";
    editBtn.style.backgroundColor = "#4ab3ff";
    editBtn.onclick = () => editData(data.id);

    const hapusBtn = document.createElement("button");
    hapusBtn.textContent = "Hapus Data";
    hapusBtn.style.backgroundColor = "#ff4d4d";
    hapusBtn.onclick = () => hapusData(data.id);

    btnGroup.appendChild(editBtn);
    btnGroup.appendChild(hapusBtn);
  }
}

// ======== UPDATE ========
function editData(id) {
  const daftar = JSON.parse(localStorage.getItem("pendaftaran")) || [];
  const index = daftar.findIndex((d) => d.id === id);
  if (index === -1) return alert("Data tidak ditemukan.");

  const nama = prompt("Nama Baru:", daftar[index].nama);
  const usia = prompt("Usia Baru:", daftar[index].usia);
  const email = prompt("Email Baru:", daftar[index].email);
  const telepon = prompt("Telepon Baru:", daftar[index].telepon);
  const program = prompt(
    "Program Baru (pemula/menengah/lanjutan):",
    daftar[index].program
  );

  if (!nama || !usia || !email || !telepon || !program)
    return alert("Perubahan dibatalkan!");

  daftar[index] = { ...daftar[index], nama, usia, email, telepon, program };
  localStorage.setItem("pendaftaran", JSON.stringify(daftar));

  alert("Data berhasil diperbarui!");
  window.location.reload();
}

// ======== DELETE ========
function hapusData(id) {
  if (!confirm("Yakin ingin menghapus data ini?")) return;
  let daftar = JSON.parse(localStorage.getItem("pendaftaran")) || [];
  daftar = daftar.filter((d) => d.id !== id);
  localStorage.setItem("pendaftaran", JSON.stringify(daftar));
  alert("Data berhasil dihapus!");
  window.location.reload();
}

// Jalankan otomatis di sumbit academy.html
document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("konfNama")) tampilkanData();
});
