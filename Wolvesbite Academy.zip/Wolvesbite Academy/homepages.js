document.addEventListener("DOMContentLoaded", function () {
  const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
  const justLoggedOut = localStorage.getItem("justLoggedOut") === "true";

  const loginLink = document.getElementById("login-link");
  const signupLink = document.getElementById("signup-link");
  const logoutLink = document.getElementById("logout-link");
  const notification = document.getElementById("logout-notification");

  if (isLoggedIn) {
    loginLink.style.display = "none";
    signupLink.style.display = "none";
    logoutLink.style.display = "block";

    logoutLink.addEventListener("click", function (e) {
      e.preventDefault();
      localStorage.removeItem("isLoggedIn");
      localStorage.setItem("justLoggedOut", "true");
      window.location.href = "homepages.html";
    });
  } else {
    logoutLink.style.display = "none";

    if (justLoggedOut && notification) {
        notification.style.display = "block";

        // Tambahkan animasi fade-out setelah 2 detik
        setTimeout(() => {
            notification.classList.add("fade-out");
        }, 2000);

        // Sembunyikan elemen setelah animasi selesai
        setTimeout(() => {
            notification.style.display = "none";
            notification.classList.remove("fade-out");
            localStorage.removeItem("justLoggedOut");
        }, 3000);
    }
  }
});