
document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("loginForm");

  form.addEventListener("submit", function (e) {
    e.preventDefault(); // cegah reload default

    // Simulasi validasi login (bisa diganti dengan API call)
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    if (email && password) {
      // Simpan status login
      localStorage.setItem("isLoggedIn", "true");

      // Redirect ke homepage
      window.location.href = "homepages.html";
    } else {
      alert("Email dan password wajib diisi!");
    }
  });
});