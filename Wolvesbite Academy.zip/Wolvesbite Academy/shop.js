// === Update Cart Count Badge ===
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  const totalItems = cart.reduce((sum, item) => sum + item.qty, 0);
  const badge = document.getElementById("cart-count");
  if (badge) badge.textContent = totalItems;
}

// === Add to Cart ===
function addToCart(name, price) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  const existing = cart.find((i) => i.name === name);
  if (existing) existing.qty++;
  else cart.push({ name, price, qty: 1 });
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCount();
  alert(`${name} berhasil ditambahkan ke keranjang!`);
}

// === Render Cart Page ===
function renderCart() {
  const tbody = document.querySelector("#cartTable tbody");
  if (!tbody) return;
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  tbody.innerHTML = "";
  let total = 0;

  cart.forEach((item, i) => {
    const subtotal = item.price * item.qty;
    total += subtotal;
    tbody.innerHTML += `
      <tr>
        <td>${item.name}</td>
        <td>Rp${item.price.toLocaleString("id-ID")}</td>
        <td>
          <button onclick="updateQty(${i}, -1)">-</button>
          ${item.qty}
          <button onclick="updateQty(${i}, 1)">+</button>
        </td>
        <td>Rp${subtotal.toLocaleString("id-ID")}</td>
        <td><button onclick="removeItem(${i})">Hapus</button></td>
      </tr>`;
  });

  document.getElementById(
    "totalPrice"
  ).textContent = `Total: Rp${total.toLocaleString("id-ID")}`;
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCount();
}

// === Update Quantity ===
function updateQty(i, delta) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart[i].qty += delta;
  if (cart[i].qty <= 0) cart.splice(i, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  renderCart();
}

// === Remove Item ===
function removeItem(i) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.splice(i, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  renderCart();
}

// === Go to Checkout ===
function goToCheckout() {
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  if (cart.length === 0) {
    alert("Keranjang masih kosong!");
    return;
  }
  window.location.href = "checkout.html";
}

// === Render Checkout Page ===
function renderCheckout() {
  const list = document.getElementById("checkoutList");
  if (!list) return;
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  list.innerHTML = "";
  let total = 0;

  cart.forEach((item) => {
    const subtotal = item.price * item.qty;
    total += subtotal;
    list.innerHTML += `<li>${item.name} x${
      item.qty
    } - Rp${subtotal.toLocaleString("id-ID")}</li>`;
  });

  document.getElementById(
    "checkoutTotal"
  ).textContent = `Total: Rp${total.toLocaleString("id-ID")}`;
  updateCartCount();
}

// === Checkout Submit ===
document.addEventListener("DOMContentLoaded", () => {
  updateCartCount();
  renderCart();
  renderCheckout();

  const form = document.getElementById("checkoutForm");
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      localStorage.removeItem("cart");
      alert(
        "Pesanan kamu berhasil diproses! Terima kasih telah berbelanja di Wolvesbite 🐺"
      );
      window.location.href = "shop.html";
    });
  }
});
